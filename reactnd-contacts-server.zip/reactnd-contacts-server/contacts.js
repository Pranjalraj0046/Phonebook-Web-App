const clone = require('clone')
const config = require('./config')

const db = {}

const defaultData = {
  contacts: [
    {
      id: 'richard',
      name: 'Elvish Rathore',
      handle: '9632587410',
      avatarURL: config.origin + '/richard.jpg'
    },
    {
      id: 'karen',
      name: 'Deepak Kumar',
      handle: '9874563210',
      avatarURL: config.origin + '/karen.jpg'
    },
     {
      id: 'Raj',
      name: 'Pranjal Raj',
      handle: '9514786320',
      avatarURL: config.origin + '/karen.jpg'
    },
     {
      id: 'Kumar',
      name: 'Ravi Singh',
      handle: '9653214870',
      avatarURL: config.origin + '/karen.jpg'
    },
    {
      id: 'tyler',
      name: 'Tony Jack',
      handle: '9658743201',
      avatarURL: config.origin + '/tyler.jpg'
    }
  ]
}

const get = (token) => {
  let data = db[token]

  if (data == null) {
    data = db[token] = clone(defaultData)
  }

  return data
}

const add = (token, contact) => {
  if (!contact.id) {
    contact.id = Math.random().toString(36).substr(-8)
  }

  get(token).contacts.push(contact)

  return contact
}

const remove = (token, id) => {
  const data = get(token)
  const contact = data.contacts.find(c => c.id === id)

  if (contact) {
    data.contacts = data.contacts.filter(c => c !== contact)
  }

  return { contact }
}

module.exports = {
  get,
  add,
  remove
}
